// =============================================================================
// Robot head firmware, USB version (the version flashed on both heads).
//
// Board: LCDWIKI ES3C28P = ESP32-S3 + 2.8" 240x320 ILI9341V screen + FT6336G touch.
// Link to the PC: the USB-C cable. It appears on the PC as /dev/ttyACM0 or
// /dev/ttyACM1 and works like a serial line at 115200 baud. No Wi-Fi is used.
//
// Text protocol, one message per line (ends with "\n"):
//   PC to head:  "SMILE"        friendly face (coordinated mode)
//                "GRUMPY"       angry brows and a frown (uncoordinated mode)
//                "FLASH 3"      backlight blinks 3 times, the picture stays
//                "SHOW RED 3"   red card with a big 3
//                "SHOW BLUE 8"  blue card with a big 8
//                "LOOK"         eyes look up at the participant
//                "IDLE"         neutral face (any unknown text also shows this)
//   Head to PC:  "HELLO robot_left"            every second, so the PC knows
//                                              which head is on which USB port
//                "TAP robot_left <x> <y>"      when the screen is touched
//
// ROBOT_NAME ("robot_left" or "robot_right") is set at build time by
// platformio.ini, so one source file gives both heads.
//   Build and flash:  pio run -e robot_left  -t upload --upload-port <port>
//                     pio run -e robot_right -t upload --upload-port <port>
// =============================================================================
#include <Arduino.h>
#include <Wire.h>        // I2C bus, used by the touch controller
#include <TFT_eSPI.h>    // screen driver; pins are set in platformio.ini
#include <cstring>
#include <cstdio>
#include <cmath>
#include <driver/i2s.h>  // ESP32 I2S driver, used for the microphone

// Touch controller FT6336G on I2C: data pin 16, clock pin 15, reset pin 18
// (pins from the LCDWIKI pin table). 0x38 is its fixed I2C address.
const int TP_SDA = 16, TP_SCL = 15, TP_RST = 18;
const uint8_t FT_ADDR = 0x38;

// Screen orientation, set in platformio.ini. 0 = portrait (vertical), USB at
// one end; 2 = portrait turned upside down. 1 and 3 would be landscape.
#ifndef SCREEN_ROTATION
#define SCREEN_ROTATION 0
#endif

// Screen size in portrait: 240 wide, 320 high. CX is the horizontal centre.
const int W = 240, H = 320, CX = W / 2;

TFT_eSPI tft;                     // the screen
bool linked = false;              // not used in the USB version (left from the Wi-Fi version)
uint16_t background = TFT_BLACK;  // colour currently filling the screen

// ---------------------------------------------------------------------------
// Drawing. The screen is used in portrait: 240 wide, 320 high, (0,0) top left.
// ---------------------------------------------------------------------------

// Two white eyes side by side in the upper half; pupilDy moves the pupils
// up (negative) or down (positive) from the eye centre.
void drawEyes(int pupilDy) {
  background = TFT_BLACK;
  tft.fillScreen(TFT_BLACK);
  tft.fillEllipse(CX - 50, 130, 34, 46, TFT_WHITE);          // left eye (centre x, y, radius x, y)
  tft.fillEllipse(CX + 50, 130, 34, 46, TFT_WHITE);          // right eye
  tft.fillCircle(CX - 50, 130 + pupilDy, 15, TFT_BLACK);     // left pupil
  tft.fillCircle(CX + 50, 130 + pupilDy, 15, TFT_BLACK);     // right pupil
}

// Neutral face: pupils slightly low.
void drawIdle() { drawEyes(12); }

// Pupils moved up: the robot "looks at" the participant.
void drawLook() { drawEyes(-20); }

// Friendly face: happy closed eyes (arcs) and a smile. Used by the coordinated mode.
// A white ellipse with a black ellipse placed slightly off it leaves a thin crescent.
void drawSmile() {
  background = TFT_BLACK;
  tft.fillScreen(TFT_BLACK);
  for (int s = -1; s <= 1; s += 2) {                         // s = -1 left eye, +1 right eye
    tft.fillEllipse(CX + s * 50, 130, 36, 36, TFT_WHITE);
    tft.fillEllipse(CX + s * 50, 146, 36, 36, TFT_BLACK);    // leaves an arc on top: ^ ^
  }
  tft.fillEllipse(CX, 205, 60, 38, TFT_WHITE);
  tft.fillEllipse(CX, 188, 60, 38, TFT_BLACK);               // leaves an arc at the bottom: a smile
}

// Grumpy face: angry eyebrows over small pupils and a frown. Used by the uncoordinated mode.
void drawGrumpy() {
  background = TFT_BLACK;
  tft.fillScreen(TFT_BLACK);
  for (int s = -1; s <= 1; s += 2) {
    tft.fillEllipse(CX + s * 50, 130, 34, 40, TFT_WHITE);
    tft.fillCircle(CX + s * 50, 142, 12, TFT_BLACK);         // small pupil
    // black triangle cuts the inner top of the eye, so the brow slopes down to the middle
    tft.fillTriangle(CX + s * 95, 80, CX + s * 8, 80, CX + s * 8, 126, TFT_BLACK);
  }
  tft.fillEllipse(CX, 215, 50, 30, TFT_WHITE);
  tft.fillEllipse(CX, 232, 50, 30, TFT_BLACK);               // leaves an arc on top: a frown
}

// Blinks the screen backlight n times quickly. The picture itself does not change,
// so a card stays readable. The uncoordinated mode uses it as an impatient nudge.
void flashBacklight(int n) {
  n = constrain(n, 1, 6);
  for (int i = 0; i < n; i++) {
    digitalWrite(TFT_BL, LOW);  delay(60);
    digitalWrite(TFT_BL, HIGH); delay(60);
  }
}

// Instruction card: the whole screen in the colour, a big white number in the
// middle, and small eyes on top so it still reads as a robot holding a card.
void drawCard(const char *colour, int number) {
  uint16_t c = (strcmp(colour, "RED") == 0) ? TFT_RED : TFT_BLUE;  // anything not RED is blue
  background = c;
  tft.fillScreen(c);
  tft.fillCircle(CX - 22, 42, 13, TFT_WHITE);   // small eyes at the top of the card
  tft.fillCircle(CX + 22, 42, 13, TFT_WHITE);
  tft.fillCircle(CX - 22, 44, 6, TFT_BLACK);
  tft.fillCircle(CX + 22, 44, 6, TFT_BLACK);
  tft.setTextColor(TFT_WHITE, c);
  tft.setTextDatum(MC_DATUM);                   // position text by its middle centre
  tft.drawNumber(number, CX, 190, 8);           // font 8: large digits (75 px high)
}

// Start-up text: robot name plus up to two status lines.
void drawStatus(const char *line1, const char *line2 = "") {   // start-up screen
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(TL_DATUM);               // position text by its top left corner
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(ROBOT_NAME, 10, 10, 4);    // font 4: medium
  tft.drawString(line1, 10, 50, 2);         // font 2: small
  tft.drawString(line2, 10, 75, 2);
}

// ---------------------------------------------------------------------------
// Microphone (on-board audio codec, test version)
//
// The board has an audio codec chip on the same I2C bus as the touch chip
// (expected: ES8311 at address 0x18) and a microphone input. The codec turns
// the microphone signal into digital samples and sends them to the ESP32 over
// I2S. Pins from the LCDWIKI pin table: master clock 4, bit clock 5,
// left/right clock 7, data from codec to ESP32 6.
//
// Commands:  I2CSCAN   list all chips on the I2C bus
//            MIC ON    set up the codec and I2S, then send
//                      "MIC <name> <level ch0> <level ch1> <peak>" 10 times per second
//            MIC OFF   stop
// The level is the RMS of the samples (16-bit, so 0 to 32767). Silence is a
// few tens; speech or a clap near the board should give hundreds or more.
// ---------------------------------------------------------------------------
const uint8_t CODEC_ADDR = 0x18;          // ES8311 I2C address
const int I2S_MCK = 4, I2S_BCK = 5, I2S_WS = 7, I2S_DIN = 6;
const int MIC_RATE = 16000;               // samples per second
bool micOn = false;

// Prints the address of every chip that answers on the I2C bus.
void i2cScan() {
  Serial.print("I2C");
  for (uint8_t a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) Serial.printf(" 0x%02X", a);
  }
  Serial.print("\n");
}

bool codecWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(CODEC_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

int codecRead(uint8_t reg) {
  Wire.beginTransmission(CODEC_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return -1;
  if (Wire.requestFrom(CODEC_ADDR, (uint8_t)1) < 1) return -1;
  return Wire.read();
}

// Starts I2S (the ESP32 produces the clocks) and sets up the codec to record
// from the analog microphone at 16 kHz, 16 bit. Register values follow
// Espressif's ES8311 driver for MCLK = 256 x sample rate in slave mode.
bool micStart() {
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX);
  cfg.sample_rate = MIC_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;    // read both slots; the mic is on one of them
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.dma_buf_count = 4;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;
  cfg.fixed_mclk = MIC_RATE * 256;                    // 4.096 MHz master clock for the codec
  cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256;
  cfg.bits_per_chan = I2S_BITS_PER_CHAN_16BIT;
  i2s_pin_config_t pins = {};
  pins.mck_io_num = I2S_MCK;
  pins.bck_io_num = I2S_BCK;
  pins.ws_io_num = I2S_WS;
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = I2S_DIN;
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) { Serial.print("MIC ERROR i2s install\n"); return false; }
  if (i2s_set_pin(I2S_NUM_0, &pins) != ESP_OK) { Serial.print("MIC ERROR i2s pins\n"); return false; }
  delay(10);   // let the master clock run before talking to the codec

  int id1 = codecRead(0xFD), id2 = codecRead(0xFE);   // ES8311 chip id: 0x83 0x11
  Serial.printf("CODEC id 0x%02X 0x%02X%s\n", id1 & 0xFF, id2 & 0xFF,
                (id1 == 0x83 && id2 == 0x11) ? " (ES8311)" : " (not an ES8311 or no answer)");
  if (id1 < 0) { i2s_driver_uninstall(I2S_NUM_0); return false; }

  const uint8_t init[][2] = {
    {0x45, 0x00}, {0x01, 0x30}, {0x02, 0x00}, {0x03, 0x10}, {0x16, 0x24},
    {0x04, 0x10}, {0x05, 0x00}, {0x0B, 0x00}, {0x0C, 0x00}, {0x10, 0x1F},
    {0x11, 0x7F}, {0x00, 0x80},               // power on, slave mode
    {0x01, 0x3F},                             // all clocks on, MCLK from the MCLK pin
    {0x06, 0x03}, {0x07, 0x00}, {0x08, 0xFF}, // clock dividers for 4.096 MHz / 16 kHz
    {0x13, 0x10}, {0x1B, 0x0A}, {0x1C, 0x6A}, // ADC high-pass and DC offset removal
    {0x09, 0x0C}, {0x0A, 0x0C},               // 16-bit I2S format in and out
    {0x17, 0xBF},                             // ADC volume 0 dB
    {0x0E, 0x02}, {0x12, 0x00},               // power up PGA, ADC modulator, DAC
    {0x14, 0x1A},                             // analog microphone input, PGA on
    {0x0D, 0x01}, {0x15, 0x40}, {0x37, 0x08}, {0x45, 0x00},
    {0x16, 0x04},                             // microphone gain 24 dB
  };
  for (auto &rv : init) {
    if (!codecWrite(rv[0], rv[1])) { Serial.printf("MIC ERROR codec write 0x%02X\n", rv[0]); return false; }
  }
  i2s_zero_dma_buffer(I2S_NUM_0);
  Serial.print("MIC started\n");
  return true;
}

void micStop() {
  if (!micOn) return;
  codecWrite(0x0E, 0xFF);        // power down ADC path
  i2s_driver_uninstall(I2S_NUM_0);
  micOn = false;
  Serial.print("MIC stopped\n");
}

// Called from loop(): reads whatever samples are ready (never waits) and sends
// the level of the last 100 ms.
void micPoll() {
  static double sum[2] = {0, 0}, sumSq[2] = {0, 0};
  static uint32_t n = 0, peak = 0, lastReport = 0;
  int16_t buf[256];
  size_t got = 0;
  while (i2s_read(I2S_NUM_0, buf, sizeof(buf), &got, 0) == ESP_OK && got > 0) {
    for (size_t i = 0; i + 1 < got / 2; i += 2) {
      for (int c = 0; c < 2; c++) {
        double v = buf[i + c];
        sum[c] += v;
        sumSq[c] += v * v;
        if ((uint32_t)abs(buf[i + c]) > peak) peak = abs(buf[i + c]);
      }
      n++;
    }
  }
  if (millis() - lastReport >= 100 && n > 0) {
    lastReport = millis();
    int level[2];
    for (int c = 0; c < 2; c++) {   // RMS around the mean, so a constant offset counts as silence
      double mean = sum[c] / n;
      level[c] = (int)sqrt(fmax(0.0, sumSq[c] / n - mean * mean));
      sum[c] = sumSq[c] = 0;
    }
    Serial.printf("MIC %s %d %d %u\n", ROBOT_NAME, level[0], level[1], (unsigned)peak);
    n = 0;
    peak = 0;
  }
}

// ---------------------------------------------------------------------------
// Commands from the PC
// ---------------------------------------------------------------------------

// Splits a line like "SHOW RED 3" into up to three words and draws the result.
void handleCommand(const char *text) {  // "SHOW RED 3", "LOOK", "IDLE" or "PONG"
  char cmd[12] = {0}, colour[12] = {0};
  int number = 0;
  sscanf(text, "%11s %11s %d", cmd, colour, &number);   // %11s: never overflow the 12-byte buffers
  if (strcmp(cmd, "PONG") == 0) return;                // Wi-Fi bridge reply; nothing to draw
  if (strcmp(cmd, "I2CSCAN") == 0) { i2cScan(); return; }
  if (strcmp(cmd, "MIC") == 0) {                        // "MIC ON" or "MIC OFF"
    if (strcmp(colour, "ON") == 0 && !micOn) micOn = micStart();
    else if (strcmp(colour, "OFF") == 0) micStop();
    return;
  }
  if (strcmp(cmd, "SHOW") == 0) drawCard(colour, number);
  else if (strcmp(cmd, "LOOK") == 0) drawLook();
  else if (strcmp(cmd, "SMILE") == 0) drawSmile();
  else if (strcmp(cmd, "GRUMPY") == 0) drawGrumpy();
  else if (strcmp(cmd, "FLASH") == 0) flashBacklight(atoi(colour));   // "FLASH 3": second word is the count
  else drawIdle();
}

// ---------------------------------------------------------------------------
// Touch
// ---------------------------------------------------------------------------

// Asks the touch chip for the current touch. Returns true and fills x, y if a
// finger is on the screen. Coordinates are the panel's raw portrait values
// (x 0..239, y 0..319); with SCREEN_ROTATION 0 they match the drawing coordinates.
bool readTouch(int &x, int &y) {        // FT6x36 register map: 0x02 = number of touches
  Wire.beginTransmission(FT_ADDR);
  Wire.write(0x02);                     // start reading at register 0x02
  if (Wire.endTransmission(false) != 0) return false;            // chip did not answer
  if (Wire.requestFrom(FT_ADDR, (uint8_t)5) < 5) return false;   // 5 bytes: count, XH, XL, YH, YL
  uint8_t touches = Wire.read() & 0x0F;
  uint8_t xh = Wire.read(), xl = Wire.read(), yh = Wire.read(), yl = Wire.read();
  if (touches == 0) return false;
  x = ((xh & 0x0F) << 8) | xl;          // raw panel coordinates (portrait): 12-bit values
  y = ((yh & 0x0F) << 8) | yl;
  return true;
}

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------

// Runs once at power-on or after reset.
void setup() {
  Serial.begin(115200);       // USB serial to the PC
  Serial.setTxTimeoutMs(0);   // never wait on USB writes when no PC program is listening
  tft.init();
  tft.setRotation(SCREEN_ROTATION);   // 0 = portrait (vertical)
  drawStatus("USB Serial Ready");

  // Reset the touch chip: hold its reset pin low for 10 ms, then give it 300 ms to start.
  pinMode(TP_RST, OUTPUT);
  digitalWrite(TP_RST, LOW);
  delay(10);
  digitalWrite(TP_RST, HIGH);
  delay(300);
  Wire.begin(TP_SDA, TP_SCL);
}

// Runs again and again, about every 2 ms.
void loop() {
  // 1. Commands from the PC: collect characters until a newline, then act on the line.
  static char buffer[64];     // static: keeps its contents between loop() calls
  static size_t pos = 0;

  while (Serial.available() > 0) {
    char c = Serial.read();

    if (c == '\n') {
      buffer[pos] = '\0';
      if (pos > 0) handleCommand(buffer);
      pos = 0;
    } else if (c != '\r') {   // ignore Windows-style line endings
      if (pos < sizeof(buffer) - 1) {
        buffer[pos++] = c;
      } else {
        pos = 0;              // line too long: throw it away
      }
    }
  }

  // 2. Heartbeat: tells the PC which head is on this USB port
  static uint32_t lastHello = 0;
  if (millis() - lastHello > 1000) {
    lastHello = millis();
    Serial.printf("HELLO %s\n", ROBOT_NAME);
  }

  // 3. Touch: report a tap, at most one every 300 ms (one finger press is many readings).
  static uint32_t lastTap = 0;
  int x, y;
  if (readTouch(x, y) && millis() - lastTap > 300) {
    lastTap = millis();
    Serial.printf("TAP %s %d %d\n", ROBOT_NAME, x, y);
  }

  // 4. Microphone level, only while "MIC ON" is active
  if (micOn) micPoll();

  delay(2);
}
