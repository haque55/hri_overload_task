#!/usr/bin/env python3
"""screen_test: sends a test command to both robot heads every 2 seconds.

Run (with the bridge running):  rosrun hri_robots screen_test.py
Both screens should cycle: red 3, idle face, blue 8, eyes looking up.
"""
import rospy
from std_msgs.msg import String


def main():
    rospy.init_node('screen_test')
    # One publisher per head; the bridge subscribes to these topics.
    left = rospy.Publisher('/robot_left/screen', String, queue_size=10)
    right = rospy.Publisher('/robot_right/screen', String, queue_size=10)
    items = ['SHOW RED 3', 'IDLE', 'SHOW BLUE 8', 'LOOK', 'SMILE', 'GRUMPY', 'FLASH 3']

    # ROS 1 needs a moment to connect a new publisher; without this wait
    # the first message is lost. Wait up to 5 s for head_bridge to subscribe.
    deadline = rospy.Time.now() + rospy.Duration(5.0)
    while (left.get_num_connections() == 0 or right.get_num_connections() == 0) \
            and rospy.Time.now() < deadline and not rospy.is_shutdown():
        rospy.sleep(0.1)

    rate = rospy.Rate(0.5)   # 0.5 Hz = one command every 2 s
    i = 0
    while not rospy.is_shutdown():
        msg = String(data=items[i % len(items)])   # cycle through the four commands
        left.publish(msg)
        right.publish(msg)
        rospy.loginfo('sent %s', msg.data)
        i += 1
        rate.sleep()


if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass
