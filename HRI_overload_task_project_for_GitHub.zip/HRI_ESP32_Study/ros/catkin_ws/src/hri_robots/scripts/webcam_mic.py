#!/usr/bin/env python3
"""webcam_mic: publishes the USB webcam's microphone in ROS.

  /audio/audio  audio_common_msgs/AudioData  raw sound: 16 kHz, mono, 16-bit little endian,
                                             0.1 s per message
  /audio/level  std_msgs/Int32               loudness (RMS, 0 to 32767) of the same 0.1 s

The sound is read with "arecord" (part of Debian, no extra install), so this
works without sudo. Start with webcam.launch, or:
  rosrun hri_robots webcam_mic.py _device:=plughw:1,0
"""
import array
import math
import subprocess

import rospy
from audio_common_msgs.msg import AudioData
from std_msgs.msg import Int32

RATE = 16000                    # samples per second
CHUNK = RATE // 10              # 0.1 s of samples per message
CHUNK_BYTES = CHUNK * 2         # 2 bytes per 16-bit sample


def main():
    rospy.init_node('webcam_mic')
    device = rospy.get_param('~device', 'plughw:1,0')
    audio_pub = rospy.Publisher('/audio/audio', AudioData, queue_size=20)
    level_pub = rospy.Publisher('/audio/level', Int32, queue_size=20)

    # arecord writes raw samples to stdout until it is stopped.
    proc = subprocess.Popen(['arecord', '-q', '-D', device, '-f', 'S16_LE', '-r', str(RATE),
                             '-c', '1', '-t', 'raw'], stdout=subprocess.PIPE)
    rospy.on_shutdown(proc.terminate)
    rospy.loginfo('webcam_mic: recording from %s at %d Hz', device, RATE)

    while not rospy.is_shutdown():
        data = proc.stdout.read(CHUNK_BYTES)
        if len(data) < CHUNK_BYTES:
            rospy.logerr('webcam_mic: arecord stopped (is the webcam plugged in? check "arecord -l")')
            break
        samples = array.array('h', data)
        mean = sum(samples) / len(samples)
        level = int(math.sqrt(sum((s - mean) ** 2 for s in samples) / len(samples)))
        audio_pub.publish(AudioData(data=list(data)))
        level_pub.publish(Int32(data=level))


if __name__ == '__main__':
    main()
