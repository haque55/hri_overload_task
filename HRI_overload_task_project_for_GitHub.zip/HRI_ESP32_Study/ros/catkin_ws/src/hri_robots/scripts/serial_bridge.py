#!/usr/bin/env python3
"""serial_bridge: connects ROS topics to the two ESP32 robot heads over USB.

  /<head>/screen  std_msgs/String, subscribed: sent to the head as one text line
  /<head>/touch   std_msgs/String, published:  "TAP x y" when the screen is tapped
  /<head>/mic_level  std_msgs/Int32, published: microphone level (RMS, 10 per second)
                  while the head's microphone is on (send "MIC ON" on /<head>/screen)

Each head runs the USB firmware (src/robot_head_usb) and appears as a serial
port under /dev/serial/by-id/. It sends "HELLO robot_left" (or robot_right)
every second, so the bridge does not need to know in advance which board is
on which port: it learns that from the HELLO lines.

Start:  rosrun hri_robots serial_bridge.py      or      roslaunch hri_robots heads_usb.launch
Needs pyserial for the system python3 (installed without sudo into ~/.local).
"""
import glob
import threading
import time

import rospy
import serial                     # pyserial
from std_msgs.msg import Int32, String   # text for commands and taps, numbers for mic level


class PortReader(threading.Thread):
    """Owns one USB serial port: opens it, reads its lines, reopens it after errors."""

    def __init__(self, path, bridge):
        super().__init__(daemon=True)   # daemon: ends together with the node
        self.path = path
        self.bridge = bridge
        self.port = None
        self.write_lock = threading.Lock()   # ROS callbacks may write while this thread reads

    def write_line(self, text):
        with self.write_lock:
            if self.port is None:
                return False
            try:
                self.port.write((text + '\n').encode())
                return True
            except (serial.SerialException, OSError):
                return False

    def run(self):
        while not rospy.is_shutdown():
            try:
                self.port = serial.Serial(self.path, 115200, timeout=0.5)
                rospy.loginfo('opened %s', self.path)
                while not rospy.is_shutdown():
                    line = self.port.readline()          # one message per line, or b'' after 0.5 s
                    if line:
                        self.bridge.on_line(self, line.decode(errors='replace').strip())
            except (serial.SerialException, OSError) as e:
                rospy.logwarn('%s: %s (retrying in 2 s)', self.path, e)
            finally:
                with self.write_lock:
                    if self.port is not None:
                        self.port.close()
                    self.port = None
                self.bridge.forget(self)
            time.sleep(2.0)   # cable unplugged or board resetting: try again later


class SerialBridge:
    def __init__(self):
        # Private parameters (set in launch/heads_usb.launch), with defaults.
        self.heads = rospy.get_param('~heads', ['robot_left', 'robot_right'])
        self.pattern = rospy.get_param('~ports', '/dev/serial/by-id/usb-Espressif*')
        self.timeout = rospy.get_param('~timeout', 3.0)   # seconds without HELLO before a head counts as lost

        self.lock = threading.Lock()
        self.readers = {}     # port path: PortReader
        self.head_port = {}   # head name: PortReader it was last heard on
        self.last_seen = {}   # head name: time of its last message

        # Per head: publish its taps, subscribe to its screen commands.
        self.touch_pub = {}
        self.mic_pub = {}
        for name in self.heads:
            self.touch_pub[name] = rospy.Publisher('/%s/touch' % name, String, queue_size=10)
            self.mic_pub[name] = rospy.Publisher('/%s/mic_level' % name, Int32, queue_size=10)
            rospy.Subscriber('/%s/screen' % name, String, self.on_screen, callback_args=name)

        self.scan(None)
        rospy.Timer(rospy.Duration(2.0), self.scan)          # pick up boards plugged in later
        rospy.Timer(rospy.Duration(1.0), self.check_links)   # report heads that went silent
        rospy.loginfo('serial_bridge: watching %s for %s', self.pattern, ', '.join(self.heads))

    def scan(self, _event):
        """Start a reader for every matching port that does not have one yet."""
        for path in sorted(glob.glob(self.pattern)):
            if path not in self.readers:
                reader = PortReader(path, self)
                self.readers[path] = reader
                reader.start()

    def on_line(self, reader, line):
        """Called by a PortReader for each line a head sends."""
        parts = line.split()
        # Expected: "HELLO robot_left", "TAP robot_left 120 200" or
        # "MIC robot_left <level ch0> <level ch1> <peak>". Ignore anything else.
        if len(parts) < 2 or parts[1] not in self.heads:
            return
        kind, name = parts[0], parts[1]
        with self.lock:
            if self.head_port.get(name) is not reader:
                rospy.loginfo('%s is on %s', name, reader.path)
            self.head_port[name] = reader
            self.last_seen[name] = rospy.get_time()
        if kind == 'TAP':
            # Published without the name, as "TAP x y", because the topic already names the head.
            self.touch_pub[name].publish(String(data=' '.join(['TAP'] + parts[2:])))
        elif kind == 'MIC' and len(parts) == 5 and parts[2].isdigit() and parts[3].isdigit():
            self.mic_pub[name].publish(Int32(data=max(int(parts[2]), int(parts[3]))))

    def forget(self, reader):
        """A port closed: drop the heads that were on it until they say HELLO again."""
        with self.lock:
            for name in [n for n, r in self.head_port.items() if r is reader]:
                del self.head_port[name]

    def on_screen(self, msg, name):
        """A ROS node published to /<name>/screen: forward the text to that head."""
        with self.lock:
            reader = self.head_port.get(name)
        if reader is None or not reader.write_line(msg.data):
            rospy.logwarn_throttle(2.0, '%s is not connected, dropped "%s"', name, msg.data)
            return
        rospy.loginfo('%s <- %s', name, msg.data)

    def check_links(self, _event):
        """Timer callback: forget heads that have been silent for longer than the timeout."""
        now = rospy.get_time()
        with self.lock:
            for name in list(self.head_port):
                if now - self.last_seen[name] > self.timeout:
                    rospy.logwarn('%s lost: no message for %.0f s', name, self.timeout)
                    del self.head_port[name]   # it comes back with its next HELLO


def main():
    rospy.init_node('serial_bridge')
    SerialBridge()
    rospy.spin()


if __name__ == '__main__':
    main()
