#!/usr/bin/env python3
"""trial_scheduler: runs one trial of the study on the two robot heads.

Started by launch/coordinated.launch or launch/uncoordinated.launch, or alone:
  rosrun hri_robots trial_scheduler.py _mode:=coordinated _sequence:=A _participant:=P01

Modes (timings from the study plan, seconds from the start of the trial):
  coordinated    both robots give a card at 0, 10, 20 ... 90
  uncoordinated  left  0, 12, 18.5, 25.5, 35.5, 49, 58, 67, 75.5, 85
                 right 2, 10.5, 23, 33.5, 40.5, 46.5, 56, 64.5, 78.5, 90
  practice       10 cards, robots take turns every 5 s (like neither mode)

Behaviour style (parameter ~style), what the robots do besides showing cards:
  friendly   (coordinated/normal launch default): predictable and polite: a smile when a
             card is done, a calm neutral face when it times out, and a smile at the end
  impatient  (legacy name for the uncoordinated launch): irregular timing, with
             the face remaining neutral after every card; no backlight flashing
  plain      no extra behaviour (cards, LOOK and the neutral face only)
The extra behaviour never changes a card's colour or number.

For each card the robot looks up (LOOK) 0.3 s before showing it (SHOW RED 3).
The card closes when the participant taps that robot's screen ("done", for now
in place of a block landing in a bin) or after 6 s ("timeout"); the robot then
goes back to its idle face.

  Every event is published as JSON on /trial/events (so rosbag records it) and
  written to ~/hri_bags/<participant>_<mode>_<sequence>_<time>_events.jsonl.

  The launch files accept speed:=2 for a quick test. This halves all planned
  times, the card timeout and the LOOK lead. The default
  speed:=1 preserves the study timing exactly.
"""
import json
import os
import threading
import time

import rospy
from std_msgs.msg import String

# Card sequences: (colour, number) per robot, 10 cards each. Both sequences use
# the same 20 numbers in a different order; the total is 97 in both.
SEQUENCES = {
    'A': {'left':  [('RED', 3), ('BLUE', 8), ('RED', 9), ('RED', 4), ('BLUE', 9),
                    ('RED', 7), ('BLUE', 3), ('RED', 6), ('BLUE', 4), ('BLUE', 2)],
          'right': [('RED', 2), ('BLUE', 1), ('BLUE', 8), ('RED', 5), ('RED', 1),
                    ('BLUE', 4), ('RED', 7), ('BLUE', 3), ('RED', 6), ('BLUE', 5)]},
    'B': {'left':  [('RED', 7), ('BLUE', 9), ('BLUE', 3), ('RED', 8), ('BLUE', 6),
                    ('RED', 5), ('RED', 2), ('BLUE', 4), ('RED', 5), ('BLUE', 7)],
          'right': [('RED', 4), ('BLUE', 3), ('RED', 4), ('BLUE', 3), ('RED', 8),
                    ('BLUE', 9), ('BLUE', 1), ('RED', 2), ('BLUE', 6), ('RED', 1)]},
    'practice': {'left':  [('RED', 1), ('BLUE', 2), ('RED', 5), ('BLUE', 7), ('RED', 9)],
                 'right': [('BLUE', 6), ('RED', 4), ('BLUE', 3), ('RED', 8), ('BLUE', 2)]},
}

# Card times in seconds from the start of the trial, per robot.
TIMES = {
    'coordinated':   {'left':  [0, 10, 20, 30, 40, 50, 60, 70, 80, 90],
                      'right': [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]},
    'uncoordinated': {'left':  [0, 12, 18.5, 25.5, 35.5, 49, 58, 67, 75.5, 85],
                      'right': [2, 10.5, 23, 33.5, 40.5, 46.5, 56, 64.5, 78.5, 90]},
    'practice':      {'left':  [0, 10, 20, 30, 40],
                      'right': [5, 15, 25, 35, 45]},
}

ROBOTS = ('left', 'right')


class TrialScheduler:
    def __init__(self):
        # Private parameters, set by the launch files.
        self.mode = rospy.get_param('~mode', 'coordinated')
        self.sequence = 'practice' if self.mode == 'practice' else str(rospy.get_param('~sequence', 'A'))
        self.participant = str(rospy.get_param('~participant', 'P00'))
        self.speed = float(rospy.get_param('~speed', 1.0))
        if self.speed <= 0:
            raise ValueError('speed must be greater than zero')
        self.timeout = float(rospy.get_param('~timeout', 6.0)) / self.speed
        self.look_lead = float(rospy.get_param('~look_lead', 0.3)) / self.speed
        self.style = rospy.get_param('~style', 'plain')        # friendly, impatient or plain
        if self.style not in ('friendly', 'impatient', 'plain'):
            raise ValueError('style must be friendly, impatient or plain')
        self.pending_face = {r: None for r in ROBOTS}   # robot: trial time when its SMILE/GRUMPY goes back to idle
        if self.mode not in TIMES or self.sequence not in SEQUENCES:
            raise ValueError('mode must be coordinated, uncoordinated or practice; sequence A or B')

        self.screen = {r: rospy.Publisher('/robot_%s/screen' % r, String, queue_size=10) for r in ROBOTS}
        self.events = rospy.Publisher('/trial/events', String, queue_size=50)
        for r in ROBOTS:
            rospy.Subscriber('/robot_%s/touch' % r, String, self.on_tap, callback_args=r)

        self.lock = threading.Lock()                 # taps arrive in another thread
        self.open_card = {r: None for r in ROBOTS}   # robot: the card it shows right now, or None
        self.results = []                            # one entry per closed card
        self.t0 = None                               # time.monotonic() at trial start
        self.accept_taps = True                      # becomes false before the event log closes

        os.makedirs(os.path.expanduser('~/hri_bags'), exist_ok=True)
        name = '%s_%s_%s_%s' % (self.participant, self.mode, self.sequence, time.strftime('%Y%m%d_%H%M%S'))
        self.log_path = os.path.expanduser('~/hri_bags/%s_events.jsonl' % name)
        self.log = open(self.log_path, 'w')

    # ---- helpers ----------------------------------------------------------
    def now(self):
        """Seconds since the trial started (monotonic clock, never jumps)."""
        return time.monotonic() - self.t0

    def emit(self, kind, **fields):
        """Publish one event on /trial/events and append it to the log file."""
        event = {'type': kind, 't': round(self.now(), 3) if self.t0 else None,
                 'ros_time': rospy.Time.now().to_sec(), 'participant': self.participant,
                 'mode': self.mode, 'sequence': self.sequence, 'style': self.style}
        event.update(fields)
        text = json.dumps(event)
        self.events.publish(String(data=text))
        self.log.write(text + '\n')
        self.log.flush()

    def send(self, robot, command):
        self.screen[robot].publish(String(data=command))

    def close_card(self, robot, how, tap=None):
        """Close the open card of one robot ("done" or "timeout"). Call with self.lock held."""
        card = self.open_card[robot]
        if card is None:
            return
        self.open_card[robot] = None
        rt = round(self.now() - card['t_show'], 3)
        self.react(robot, how)
        self.emit(how, robot=robot, k=card['k'], colour=card['colour'], number=card['number'],
                  response_time=rt if how == 'done' else None, tap=tap)
        self.results.append({'robot': robot, 'how': how, 'rt': rt})
        print('  %6.2f s  %-5s card %2d %-4s %d  %s%s' % (
            self.now(), robot, card['k'], card['colour'], card['number'], how.upper(),
            '  after %.2f s' % rt if how == 'done' else ''), flush=True)

    def react(self, robot, how):
        """The face a robot shows after its card closed ("done" or "timeout"), by style."""
        faces = {'friendly': {'done': 'SMILE', 'timeout': 'IDLE'},
                 # Keep the irregular timing without an angry face or flashing.
                 'impatient': {'done': 'IDLE', 'timeout': 'IDLE'}}.get(self.style)
        face = faces[how] if faces else 'IDLE'
        self.send(robot, face)
        # a smile or grumpy face stays for 1.2 s, then the neutral face returns
        self.pending_face[robot] = self.now() + 1.2 if face != 'IDLE' else None

    # ---- ROS callback -----------------------------------------------------
    def on_tap(self, msg, robot):
        """A tap on a robot's screen means: the block for its open card is done."""
        if self.t0 is None or not self.accept_taps:
            return
        tap = msg.data.split()[1:]   # "TAP x y" gives ["x", "y"]
        with self.lock:
            if self.open_card[robot] is None:
                self.emit('tap_no_card', robot=robot, tap=tap)
                print('  %6.2f s  %-5s tap, but no card open' % (self.now(), robot), flush=True)
            else:
                self.close_card(robot, 'done', tap=tap)

    # ---- the trial --------------------------------------------------------
    def build_actions(self):
        """All timed actions of the trial (LOOK and SHOW per card), sorted by time."""
        actions = []
        scale = 1.0 / self.speed
        for robot in ROBOTS:
            cards = zip(TIMES[self.mode][robot], SEQUENCES[self.sequence][robot])
            for k, (t, (colour, number)) in enumerate(cards, 1):
                scaled_t = t * scale
                card = {'k': k, 'colour': colour, 'number': number, 't_plan': scaled_t}
                actions.append((max(0.0, scaled_t - self.look_lead), 0, 'look', robot, card))
                actions.append((scaled_t, 1, 'show', robot, card))
        return sorted(actions, key=lambda a: (a[0], a[1], a[3]))

    def wait_for_connections(self):
        """Wait (up to 10 s) until the head bridge and the recorder are listening."""
        deadline = time.time() + 10
        while not rospy.is_shutdown() and time.time() < deadline:
            if all(self.screen[r].get_num_connections() > 0 for r in ROBOTS) and self.events.get_num_connections() > 0:
                return
            time.sleep(0.1)
        missing = ['/robot_%s/screen' % r for r in ROBOTS if self.screen[r].get_num_connections() == 0]
        if self.events.get_num_connections() == 0:
            missing.append('/trial/events (no recorder)')
        rospy.logwarn('nobody listens on: %s (is the bridge / rosbag running?)', ', '.join(missing))

    def run(self):
        actions = self.build_actions()
        self.wait_for_connections()
        for r in ROBOTS:
            self.send(r, 'IDLE')
        print('\nTrial: participant %s, mode %s, sequence %s, %d cards.\n'
              'Tap a robot\'s screen when its block is done.' %
              (self.participant, self.mode.upper(), self.sequence, len(actions) // 2), flush=True)
        for n in (3, 2, 1):
            print('  starting in %d ...' % n, flush=True)
            time.sleep(1)

        self.t0 = time.monotonic()
        self.emit('trial_start', n_cards=len(actions) // 2)
        print('    0.00 s  TRIAL START', flush=True)

        i = 0
        last_time = actions[-1][0]
        while not rospy.is_shutdown():
            t = self.now()
            with self.lock:
                # 1. timed actions that are due now
                while i < len(actions) and actions[i][0] <= t:
                    t_plan, _, kind, robot, card = actions[i]
                    i += 1
                    if kind == 'look':
                        if self.open_card[robot] is None:      # never cover a card that is still open
                            self.pending_face[robot] = None
                            self.send(robot, 'LOOK')
                            self.emit('look', robot=robot, k=card['k'], t_plan=round(t_plan, 3))
                    else:
                        if self.open_card[robot] is not None:   # cannot happen with these schedules
                            self.close_card(robot, 'timeout')
                        self.pending_face[robot] = None
                        self.send(robot, 'SHOW %s %d' % (card['colour'], card['number']))
                        card['t_show'] = self.now()
                        self.open_card[robot] = card
                        self.emit('show', robot=robot, k=card['k'], colour=card['colour'], number=card['number'],
                                  t_plan=card['t_plan'], late_ms=round((card['t_show'] - card['t_plan']) * 1000, 1))
                        print('  %6.2f s  %-5s card %2d SHOW %-4s %d' % (
                            card['t_show'], robot, card['k'], card['colour'], card['number']), flush=True)
                # 2. cards that have been open for too long
                for robot in ROBOTS:
                    card = self.open_card[robot]
                    if card is not None and t - card['t_show'] >= self.timeout:
                        self.close_card(robot, 'timeout')
                    # bring the neutral face back after a smile or grumpy face
                    if self.pending_face[robot] is not None and t >= self.pending_face[robot] \
                            and self.open_card[robot] is None:
                        self.pending_face[robot] = None
                        self.send(robot, 'IDLE')
                finished = i >= len(actions) and all(self.open_card[r] is None for r in ROBOTS)
            if finished or t > last_time + self.timeout + 1:
                break
            time.sleep(0.005)   # 5 ms steps: card times are accurate to a few milliseconds
        self.summary()

    def summary(self):
        # Stop accepting callbacks before closing the JSONL file. A touch can
        # arrive just after the final timeout/trial_end event; it must not try
        # to write to the closed log.
        self.accept_taps = False
        done = [r['rt'] for r in self.results if r['how'] == 'done']
        n_timeout = len(self.results) - len(done)
        mean_rt = round(sum(done) / len(done), 3) if done else None
        if self.style == 'friendly':           # thank-you smile at the end of the trial
            for r in ROBOTS:
                self.send(r, 'SMILE')
        self.emit('trial_end', n_done=len(done), n_timeout=n_timeout, mean_response_time=mean_rt)
        print('\n  %6.2f s  TRIAL END: %d cards done by tap, %d timed out%s' % (
            self.now(), len(done), n_timeout, ', mean response time %.2f s' % mean_rt if done else ''), flush=True)
        if self.mode != 'practice':
            print('  Ask the participant for the running sum now (correct total: 97).', flush=True)
        print('  Event log: %s' % self.log_path, flush=True)
        self.log.close()


def main():
    rospy.init_node('trial_scheduler')
    TrialScheduler().run()
    time.sleep(1.0)   # give the recorder time to store the last events


if __name__ == '__main__':
    main()
