#!/usr/bin/env bash
# session.sh: runs one complete participant session, step by step.
#
#   rosbag and the two trials are started for you; the experimenter only presses
#   Enter between steps and types the participant's answers.
#
#   Before:  terminal 1  roscore
#            terminal 2  roslaunch hri_robots webcam.launch
#            terminal 3  roslaunch hri_robots heads_usb.launch
#   Then:    rosrun hri_robots session.sh P07
#
# Order of a session:
#   1. checks that the heads, camera and microphone are running
#   2. practice round (10 cards, not recorded)
#   3. trial 1, recorded; then the reported running sum; then questionnaire pause
#   4. trial 2, recorded; then the reported running sum; then questionnaire pause
#   5. setup choice ("which setup for a full work shift: first or second?")
# Everything goes to ~/hri_bags/<participant>/, with a summary in session_<participant>.csv.
#
# Counterbalancing: the participant number picks one of 4 groups, in this rotation:
#   P01 group 1  coordinated first,   coordinated uses sequence A, uncoordinated B
#   P02 group 2  uncoordinated first, coordinated uses sequence A, uncoordinated B
#   P03 group 3  coordinated first,   coordinated uses sequence B, uncoordinated A
#   P04 group 4  uncoordinated first, coordinated uses sequence B, uncoordinated A
#   P05 group 1 again, and so on. 16 participants give 4 per group.
set -u

if [ $# -ne 1 ]; then echo "usage: session.sh <participant id, e.g. P07>"; exit 1; fi
P=$1
NUM=$(echo "$P" | tr -cd '0-9' | sed 's/^0*//')
if [ -z "$NUM" ]; then NUM=1; fi                # IDs without a number (e.g. TEST) use group 1
GROUP=$(( (NUM - 1) % 4 + 1 ))
case $GROUP in
  1) MODES=(coordinated uncoordinated); SEQS=(A B) ;;
  2) MODES=(uncoordinated coordinated); SEQS=(B A) ;;
  3) MODES=(coordinated uncoordinated); SEQS=(B A) ;;
  4) MODES=(uncoordinated coordinated); SEQS=(A B) ;;
esac

OUT=~/hri_bags/$P
mkdir -p "$OUT"
CSV=$OUT/session_$P.csv
[ -f "$CSV" ] || echo "participant,group,trial,mode,sequence,bag,events,reported_sum,correct_sum,sum_error" > "$CSV"

say()  { echo -e "\n\033[1;36m===== $* =====\033[0m"; }
show() { echo -e "\033[1;33m\$ $*\033[0m"; }
ask_enter() { echo -e "\033[1;32m$*\033[0m"; read -r -p "   Press Enter to continue... " _; }

say "SESSION $P  (group $GROUP: ${MODES[0]} with sequence ${SEQS[0]} first, then ${MODES[1]} with sequence ${SEQS[1]})"

# ---- 1. checks --------------------------------------------------------------
say "1. CHECKS"
ok=1
rosnode list >/dev/null 2>&1 || { echo "   roscore is not running (terminal 1)"; ok=0; }
if [ $ok = 1 ]; then
  rosnode list | grep -q '^/serial_bridge$' && echo "   robot heads bridge: running" || { echo "   robot heads bridge NOT running (terminal 3: roslaunch hri_robots heads_usb.launch)"; ok=0; }
  rosnode list | grep -q '^/camera/color$'  && echo "   webcam: running"             || { echo "   webcam NOT running (terminal 2: roslaunch hri_robots webcam.launch)"; ok=0; }
  rosnode list | grep -q '^/webcam_mic$'    && echo "   webcam microphone: running"  || echo "   webcam microphone not running (optional)"
fi
if [ $ok = 0 ]; then echo -e "\033[1;31m   Start the missing terminals, then run this again.\033[0m"; exit 1; fi
show "rostopic pub -1 /robot_left/screen std_msgs/String \"data: 'MIC ON'\"   (and the same for the right head)"
rostopic pub -1 /robot_left/screen  std_msgs/String "data: 'MIC ON'" >/dev/null
rostopic pub -1 /robot_right/screen std_msgs/String "data: 'MIC ON'" >/dev/null
echo "   robot head microphones: on"

# ---- 2. practice ------------------------------------------------------------
say "2. PRACTICE ROUND (10 cards, not recorded)"
ask_enter "Explain the task to the participant. Start the practice when they are ready."
show "roslaunch hri_robots practice.launch participant:=$P"
roslaunch hri_robots practice.launch participant:=$P 2>&1 | grep -E "Trial|card|TRIAL|tap|WARN"
rm -f ~/hri_bags/${P}_practice_*_events.jsonl   # practice is not analysed

# ---- 3 and 4. the two trials --------------------------------------------------
for i in 0 1; do
  T=$((i + 1)); MODE=${MODES[$i]}; SEQ=${SEQS[$i]}
  say "$((T + 2)). TRIAL $T: ${MODE^^} (sequence $SEQ)"
  ask_enter "Remind the participant: sorting first, and keep the running sum. Start trial $T."
  BAGBASE=$OUT/${P}_trial${T}_${MODE}_${SEQ}
  # record all topics except the raw (uncompressed) image; its compressed copy is kept
  show "rosbag record -a -x \"/camera/color/image_raw\$|.*theora.*|.*compressedDepth.*\" -o $BAGBASE"
  rosbag record -a -x "/camera/color/image_raw$|.*theora.*|.*compressedDepth.*" -o "$BAGBASE" \
      __name:=session_recorder >/dev/null 2>&1 &
  REC=$!
  sleep 3                                       # let the recorder subscribe before the trial starts
  show "roslaunch hri_robots $MODE.launch participant:=$P sequence:=$SEQ record:=false"
  roslaunch hri_robots $MODE.launch participant:=$P sequence:=$SEQ record:=false 2>&1 \
      | grep -E "Trial|card|TRIAL|tap|WARN|Event log"
  sleep 1
  kill -INT $REC; wait $REC 2>/dev/null         # Ctrl+C for rosbag: closes the bag cleanly
  BAG=$(ls -t "$BAGBASE"_*.bag 2>/dev/null | head -1)
  EV=$(ls -t ~/hri_bags/${P}_${MODE}_${SEQ}_*_events.jsonl 2>/dev/null | head -1)
  [ -n "$EV" ] && mv "$EV" "$OUT/" && EV=$OUT/$(basename "$EV")
  echo "   bag:    $BAG"
  echo "   events: $EV"

  read -r -p $'\n\033[1;32m   Ask for the running sum. Type the number the participant says: \033[0m' SUM
  if [[ "$SUM" =~ ^-?[0-9]+$ ]]; then ERR=$(( SUM > 97 ? SUM - 97 : 97 - SUM )); else ERR=""; fi
  echo "$P,$GROUP,$T,$MODE,$SEQ,$(basename "${BAG:-none}"),$(basename "${EV:-none}"),$SUM,97,$ERR" >> "$CSV"
  echo "   saved: reported $SUM, correct 97, error ${ERR:-?}"

  ask_enter "Questionnaire now: manipulation check and NASA-TLX for this trial."
done

# ---- 5. setup choice --------------------------------------------------------
say "5. SETUP CHOICE"
echo "   Ask: \"If you had to do this task for a full work shift, which setup would you choose,"
echo "         the first or the second?\""
read -r -p $'\033[1;32m   Type 1 (first) or 2 (second): \033[0m' CHOICE
case $CHOICE in 1) CHOSEN=${MODES[0]} ;; 2) CHOSEN=${MODES[1]} ;; *) CHOSEN=unknown ;; esac
echo "$P,$GROUP,choice,$CHOSEN,,,,,," >> "$CSV"
echo "   saved: chose the $CHOSEN setup"

rostopic pub -1 /robot_left/screen  std_msgs/String "data: 'IDLE'" >/dev/null
rostopic pub -1 /robot_right/screen std_msgs/String "data: 'IDLE'" >/dev/null
say "SESSION $P DONE"
echo "   Interview questions, then debrief. All files are in $OUT:"
ls -lh "$OUT" | tail -n +2 | awk '{print "     " $5 "  " $9}'
echo
cat "$CSV"
