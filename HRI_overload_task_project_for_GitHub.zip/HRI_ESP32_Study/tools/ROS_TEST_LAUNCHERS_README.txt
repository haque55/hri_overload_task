ROS manual test launchers
========================

Files:
  run_coordinated_test.sh    Both robot heads show cards together.
  run_uncoordinated_test.sh  Cards appear at different times; no flickering.
  run_practice_test.sh       Short 10-card practice round.

Before running one:
  1. Start ROS master: roscore
  2. Start the hardware: roslaunch hri_robots bringup.launch
  3. Double-click the desired .sh file, or run it from a terminal.

The tests use normal speed (1x) and do not record bags.
Touch each screen when its card appears. Stop with Ctrl+C.

Optional participant ID and sequence:
  ./run_coordinated_test.sh TEST_MANUAL A
  ./run_uncoordinated_test.sh TEST_MANUAL B
  ./run_practice_test.sh TEST_MANUAL

Project workspace:
  /home/hri26-group4/catkin_ws
