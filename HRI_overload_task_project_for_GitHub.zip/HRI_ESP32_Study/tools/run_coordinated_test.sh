#!/usr/bin/env bash
# Manual coordinated ROS test. Requires roscore, the USB head bridge and webcam.
set -u
SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"

# When launched from the file manager, open a visible terminal for ROS output.
if [ -z "${TERM:-}" ] || [ "${TERM:-}" = "dumb" ]; then
  gnome-terminal --working-directory="$SCRIPT_DIR" -- "$SCRIPT_DIR/$(basename -- "$0")" "$@"
  exit $?
fi

source /opt/ros/one/setup.bash
source /home/hri26-group4/catkin_ws/devel/setup.bash

PARTICIPANT="${1:-TEST_MANUAL}"
SEQUENCE="${2:-A}"

if ! rosnode list >/dev/null 2>&1; then
  echo "ROS master is not running. Start roscore first."
  read -r -p "Press Enter to close..."
  exit 1
fi
for node in /serial_bridge /camera/color; do
  if ! rosnode list | grep -qx "$node"; then
    echo "Required node is missing: $node"
    echo "Start: roslaunch hri_robots bringup.launch"
    read -r -p "Press Enter to close..."
    exit 1
  fi
done

echo "Starting COORDINATED test at normal speed (1x)."
echo "Participant: $PARTICIPANT   Sequence: $SEQUENCE"
echo "Recording is OFF. Touch each card when it appears."
echo "Press Ctrl+C to stop."
roslaunch hri_robots coordinated.launch participant:="$PARTICIPANT" sequence:="$SEQUENCE" record:=false speed:=1
