# HRI Overload Task

ROS 1 project for two ESP32 robot heads connected to one PC by USB, with
coordinated and uncoordinated interaction modes, touch input, webcam video,
and microphone capture.

## Repository layout

- `HRI_ESP32_Study/ros/catkin_ws/src/hri_robots/` — active ROS package.
- `HRI_ESP32_Study/firmware/robot_head/` — PlatformIO firmware for both heads.
- `HRI_ESP32_Study/tools/` — executable manual test launchers.
- `HRI_ESP32_Study/docs/` — project structure, handoff, and calibration notes.

Generated catkin files, PlatformIO `.pio` output, and experiment bags are
intentionally ignored. Bags should remain local or be stored separately.

## Quick start

```bash
source /opt/ros/one/setup.bash
cd HRI_ESP32_Study/ros/catkin_ws
catkin_make
source devel/setup.bash
roscore
roslaunch hri_robots bringup.launch
```

The USB bridge identifies the heads from their `HELLO robot_left` and
`HELLO robot_right` messages, so Wi-Fi is not required for the current setup.

Use the tools in `HRI_ESP32_Study/tools/` for normal-speed manual tests.
The uncoordinated mode has irregular timing but no backlight flickering.

Camera calibration remains pending. The webcam is usable for video/audio;
calibration is required before using it for accurate geometric measurements.
